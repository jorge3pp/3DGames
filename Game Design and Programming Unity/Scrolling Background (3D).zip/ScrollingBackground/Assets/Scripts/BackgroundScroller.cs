﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundScroller : MonoBehaviour
{
    public float scrollSpeed = 2;
    public Vector2 scrollDirection = new Vector2(-1, 0);

    private MeshRenderer sprite;

    void Start()
    {
        sprite = GetComponent<MeshRenderer>();    
    }

    void Update()
    {
        sprite.material.mainTextureOffset += scrollDirection * scrollSpeed * Time.deltaTime;
    }
}
