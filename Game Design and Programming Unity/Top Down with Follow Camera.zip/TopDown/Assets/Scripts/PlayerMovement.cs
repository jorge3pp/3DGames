﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5;

    private Vector2 inputAmount = Vector2.zero;
    private Rigidbody2D body;

    public float direction = 0;
    public Vector3 lastCheckpoint;

    private Vector3 mousePosition;

    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        lastCheckpoint = transform.position;
    }

    void Update()
    {
        inputAmount.x = Input.GetAxis("Horizontal");
        inputAmount.y = Input.GetAxis("Vertical");

        direction = inputAmount.x;

        inputAmount *= speed;
        inputAmount = Vector2.ClampMagnitude(inputAmount, speed);

        body.velocity = inputAmount;

        mousePosition = Input.mousePosition;

       mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 diff = mousePosition - transform.position;
        float angle = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        string tag = collision.gameObject.tag;
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        string tag = collider.gameObject.tag;

        if(tag == "Checkpoint")
        {
            lastCheckpoint = collider.gameObject.transform.position;
        }
        else if(tag == "Kill")
        {
            transform.position = lastCheckpoint;
        }
    }
}

