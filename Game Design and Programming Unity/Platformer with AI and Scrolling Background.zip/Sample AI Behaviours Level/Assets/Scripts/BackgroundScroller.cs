﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BackgroundScroller : MonoBehaviour
{
    public Vector2 scrollDirection = new Vector2(-1, 0);
    public PlayerMovement playerMovement;

    //private MeshRenderer sprite;
    private Image sprite;
    void Start()
    {
        //sprite = GetComponent<MeshRenderer>();    
        sprite = GetComponent<Image>();
    }

    void Update()
    {
        sprite.material.mainTextureOffset += scrollDirection * -playerMovement.direction / 5 * Time.deltaTime;
    }
}
