﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    GameObject Ammo;
    GameObject Health;
    GameObject Zombie;

    void Update()
    {
        SpawnObject(Ammo, new Vector2(10, 10));
        SpawnObject(Health, new Vector2(10, 10));
        SpawnObject(Zombie, new Vector2(10, 10));
    }

    public void SpawnObject(GameObject gameObject, Vector2 location)
    {
        GameObject go = Instantiate(gameObject);
        go.transform.position = location;
    }
}
