﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour {

    //the inventory of the player
    //this is set via drag and drop of the player oject in the Unity Editor
    public BasicInventory inventoryToWatch;

    //variables to hold the textboxes we use in the UI
    public Text healthText;
    public Text ammoText;
    public Text coinText;

    void Update()
    {
        //check that the invenotry has been assigned
        if (inventoryToWatch != null)
        {
            //Set the text of textbox to be the number of invenotry items stred in the BasicInventory
            healthText.text = inventoryToWatch.GetItemCount(InventoryItem.HealthFlask).ToString();
            ammoText.text = inventoryToWatch.GetItemCount(InventoryItem.Ammo).ToString();
            coinText.text = inventoryToWatch.GetItemCount(InventoryItem.Coin).ToString();
        }
    }
}
