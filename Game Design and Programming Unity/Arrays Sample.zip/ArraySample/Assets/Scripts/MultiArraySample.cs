﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiArraySample : MonoBehaviour
{
    //A 2D array of strings
    public string[,] stringArray;

    void Start()
    {
        InitializeArray();
    }

    private void InitializeArray()
    {
        //intialize a 2x2 array of strings
        //stringArray = new string[width, height]
        stringArray = new string[2, 2];

        //manually initializing the array
        //requires the row and column index 
        //of where the element is to be stored
        stringArray[0, 0] = "Data1";
        stringArray[1, 0] = "Data2";
        stringArray[0, 1] = "Data3";
        stringArray[1, 1] = "Data4";

        /*
         *  [0,0][1,0] = [Data1][Data2]
         *  [0,1][1,1] = [Data3][Data4]
         */

        //get the length of the first dimension of the array
        int arrayWidth = stringArray.GetLength(0);

        //get the length of the second dimension of the array
        int arrayHeight = stringArray.GetLength(1);

        //using a nested for loop we can add data to the array
        //x will loop until it reaches the length of the first array dimension
        for (int x = 0; x < arrayWidth; x++)
        {
            //x will loop until it reaches the length of the second array dimension
            for (int y = 0; y < arrayHeight; y++)
            {
                //update the element at the index [x,y]
                stringArray[x, y] = "Data" + x + y;
            }
        }
    }
}
