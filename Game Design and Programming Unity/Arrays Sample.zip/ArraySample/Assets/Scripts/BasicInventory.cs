﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum InventoryItem
{
    HealthFlask = 0,
    Ammo = 1,
    Coin = 2
}

public class BasicInventory : MonoBehaviour
{
    public int[] inventory;

    void Start()
    {
        InitializeInventory();
    }

    private void InitializeInventory()
    {
        //create aaray of size 3
        inventory = new int[3];

        //InnveotnoryItem can be converted to an integer
        //we can use this int as the index for each invetory item
        inventory[(int)InventoryItem.HealthFlask] = 5;
        inventory[(int)InventoryItem.Ammo] = 100;
        inventory[(int)InventoryItem.Coin] = 200;
    }

    public void AddToInventory(InventoryItem itemsType, int numberToAdd)
    {
        inventory[(int)itemsType] += numberToAdd;
    }

    public int GetItemCount(InventoryItem itemType)
    {
        //return the value at the given index
        //remember InventoryItem enum goes from 0 -3
        return inventory[(int)itemType];
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if (tag == "Pickup")
        {
            Pickup collectedPickup = collision.gameObject.GetComponent<Pickup>();
            AddToInventory(collectedPickup.PickupType, collectedPickup.Quantity);

            Destroy(collision.gameObject);
        }
    }
}
