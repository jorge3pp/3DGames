﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleArraySample : MonoBehaviour
{
    /*
    * Definition of three arrays (int, string, float)
    *Note that these arrays have not been instantiated (initialized)
    * In Unity these arrays will show in the Unity Editor allowing you set their size and starting data directly in the Editor
    */
    public int[] integerArray;
    public string[] stringArray;
    public float[] floatArray;


    public bool doInitializeArraysInCode = false;

    void Start()
    {
        if(doInitializeArraysInCode)
        {
            InitializeArrays();
        }
    }

    private void InitializeArrays()
    {
        integerArray = new int[3] { 21, 65, 87 };
        stringArray = new string[3] { "Data1", "Data2", "Data3" };
        floatArray = new float[3] { 0.1f, 2.6f, 8.9f };
    }

    public void AddToIntArray(int index, int value)
    {
        //check if the index is inside the bounds of the array
        //no bigger or smaller than array size
        if(index >= 0 && index < integerArray.Length)
        {
            //update the array at the given index 
            //use the data (value) passed into the method
            integerArray[index] = value;
        }
    }

    public int GetFromIntArray(int index)
    {
        //check if the index is inside the bounds of the array
        //no bigger or smaller than array size
        if (index >= 0 && index < integerArray.Length)
        {
            //return the element int the array at the given index 
           return integerArray[index];
        }
        else
        {
            //some form of fallback if the index is out of bounds
            return -1;
        }
    }

    public void AddToStringArray(int index, string value)
    {
        if (index >= 0 &&  index< stringArray.Length)
        {
            stringArray[index] = value;
        }
    }

    public void AddToFloatArray(int index, float value)
    {
        if (index >= 0 && index < floatArray.Length)
        {
            floatArray[index] = value;
        }
    }
}
