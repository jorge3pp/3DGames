﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CountEnemiesScript : MonoBehaviour
{
    public int numberOfEnemies = 0;

    void Start()
    {
        numberOfEnemies = CountObjectsWithTag("Enemy");

        Debug.Log("Enemies in Scene: " + numberOfEnemies);
    }

    public int CountObjectsWithTag(string tag)
    {
        //FindGameObjectsWithTag returns an array of all object with the desired tag
        //we only want the length of the array (number of objects found)
        return GameObject.FindGameObjectsWithTag(tag).Length;
    }

    private void Update()
    {
        if (numberOfEnemies == 0)
        {
            //game/scene over
        }
    }
}
