﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public enum TileType
{
    Dirt,
    Sand,
    Grass,
    Stone,
    Radiation
}

public class HexTile : MonoBehaviour
{
    public TileType TileType;
}
