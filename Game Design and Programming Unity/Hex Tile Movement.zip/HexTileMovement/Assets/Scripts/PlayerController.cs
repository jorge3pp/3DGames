﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Vector2 destination;
    public float moveSpeed = 2;
    public float maxMoveDistance = 2;
    private bool isMoving = false;

    void Update()
    {
        if(Input.GetMouseButtonUp(0))
        {
          Vector2 mousePosition =  Camera.main.ScreenToWorldPoint(Input.mousePosition);
          Collider2D hitCollider =  Physics2D.OverlapPoint(mousePosition);

            if (hitCollider != null)
            {
                MoveToTile(hitCollider.gameObject);
            }
        }

        if(isMoving)
        {
            transform.position = Vector2.MoveTowards(transform.position, destination, moveSpeed * Time.deltaTime);

            if(Vector2.Distance(transform.position, destination) <= 0.2f)
            {
                isMoving = false;
            }
        }
    }

    public void MoveToTile(GameObject tile)
    {
        TileType type = tile.GetComponent<HexTile>().TileType;

        if(type != TileType.Stone)
        {
            if (Vector2.Distance(transform.position, tile.transform.position) <= maxMoveDistance)
            {
                destination = tile.transform.position;
                isMoving = true;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if(tag == "Tile")
        {
            HexTile tile = collision.gameObject.GetComponent<HexTile>();

            HandleTileCollision(tile.TileType);
        }
    }

    private void HandleTileCollision(TileType tile)
    {
        switch(tile)
        {
            case TileType.Dirt:
                break;

            case TileType.Grass:
                break;

            case TileType.Radiation:
                break;

            case TileType.Sand:
                break;
        }
    }
}
