﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DialogueScreenController : MonoBehaviour
{
    public Sprite Sprites;

    public string[] Dialogue;
    private int dialogueIndex = 0;
    public string sceneAfter = "level1";

    public Image sprite;
    public Text text;

    void Start()
    {
        NextDialogue();
    }

    public void NextDialogue()
    {
        if(dialogueIndex < Dialogue.Length)
        {
            text.text = Dialogue[dialogueIndex];
            dialogueIndex++;
        }
        else
        {
            NextScene();
        }
    }

    public void NextScene()
    {
        SceneManager.LoadScene(sceneAfter);
    }
}
