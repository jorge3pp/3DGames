﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NpcDialogue : MonoBehaviour
{
    public Canvas dialogueCanvas;
    public bool isPlayerInRange = false;
    public string[] Dialogue;
    private int dialogueIndex = 0;
    public Text text;

    public bool isDialogueComplete = false;

    void Start()
    {
        dialogueCanvas.enabled = isPlayerInRange;
        NextDialogue();
    }

    void Update()
    {
        if(isPlayerInRange && !isDialogueComplete)
        {
            if(Input.GetKeyUp(KeyCode.Return))
            {
                NextDialogue();
            }
        }
    }

    public void NextDialogue()
    {
        if (dialogueIndex < Dialogue.Length)
        {
            text.text = Dialogue[dialogueIndex];
            dialogueIndex++;
        }
        else
        {
            isDialogueComplete = true;
            SetCanvasVisibility(false);
        }
    }

    public void SetCanvasVisibility(bool isVisible)
    {
        dialogueCanvas.enabled = isVisible;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if(tag == "Player" && !isDialogueComplete)
        {
            isPlayerInRange = true;
            SetCanvasVisibility(isPlayerInRange);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if (tag == "Player" && !isDialogueComplete)
        {
            isPlayerInRange = false;
            SetCanvasVisibility(isPlayerInRange);
        }
    }
}
