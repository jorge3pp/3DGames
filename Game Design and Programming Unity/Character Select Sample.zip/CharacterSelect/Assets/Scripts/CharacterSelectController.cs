﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;

public class CharacterSelectController : MonoBehaviour
{
    private PersistentData data;

    void Start()
    {
        //find the object with the PersistentData script. I have created a tag called Data to identify it
        GameObject peristent = GameObject.FindGameObjectWithTag("Data");
        data = peristent.GetComponent<PersistentData>();
    }

    // any int can be passed to this method
    public void SelectCharacter(int character)
    {
        //the CharacterType enum only goies from 0 to 2
        //I'm checking to see if the int passed in is within the range of the enum
        if (Enum.IsDefined(typeof(CharacterType), character))
        {
            //set the character type in the PersistentData script
            //remember this value will be carried over into the next scene
            data.Character = (CharacterType)character;
            LoadScene("game");
        }
    }

    public void LoadScene(string levelName)
    {
        SceneManager.LoadScene(levelName);
    }

}
