﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersistentData : MonoBehaviour
{
    //what character has the user picked
    public CharacterType Character;

    void Start()
    {
        //calling this method ensures this object will not be deleted when moving between scenes
        //use this as a way to carry data between scenes
        DontDestroyOnLoad(this);
    }
}

//an enum is a fixed user defined list
//instead of using ints/strings etc. we can now use a fixed range of values that have a descriptive meaning
//you do not need to assign the int value to each enum option
//look at SelectCharacter method in the CharacterSelectController script 
public enum CharacterType
{
    One =0,
    Two = 1,
    Three = 2
}
