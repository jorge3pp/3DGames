﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject objectToSpawn;
    private float elapsed = 0;
    private float spawnTime = 0;

    public float minSpawnTime = 1;
    public float maxSpawnTime = 5;


    void Start()
    {
        spawnTime = PickRandomTime();
    }

    void Update()
    {
        elapsed += Time.deltaTime;

        if(elapsed >= spawnTime)
        {
            Instantiate(objectToSpawn, transform.position, Quaternion.identity);
            spawnTime = PickRandomTime();
            elapsed = 0;
        }
    }

    float PickRandomTime()
    {
        return Random.Range(minSpawnTime, maxSpawnTime);
    }
}
