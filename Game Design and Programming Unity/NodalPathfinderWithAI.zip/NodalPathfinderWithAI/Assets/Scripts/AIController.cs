﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIController : MonoBehaviour
{

    public Grid navArea;
    private BreadCrumb currentPath;
    private Vector2 targetPosition;

    public bool doMove = false;
    public float moveSpeed = 3;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //Convert mouse click point to grid coordinates
            Vector2 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Point gridPos = navArea.WorldToGrid(worldPos);

            if (gridPos != null)
            {

                if (gridPos.X > 0 && gridPos.Y > 0 && gridPos.X < navArea.Width && gridPos.Y < navArea.Height)
                {
                    //Convert player point to grid coordinates
                    Point playerPos = navArea.WorldToGrid(transform.position);

                    //Find path from player to clicked position
                    currentPath = PathFinder.FindPath(navArea, playerPos, gridPos);
                    targetPosition = Grid.GridToWorld(currentPath.position);
                    doMove = true;
                }
                else
                {
                    doMove = false;
                }
            }
        }

        if(doMove && currentPath != null)
        {
            MoveToNode();
        }
    }

    void MoveToNode()
    {
        if (Vector2.Distance(transform.position, targetPosition) <= 0.2f)
        {
            currentPath = currentPath.next;

            if (currentPath != null)
            {
                targetPosition = Grid.GridToWorld(currentPath.position);
            }
            else
            {
                doMove = false;
            }
        }

        transform.position = Vector2.MoveTowards(transform.position, Grid.GridToWorld(currentPath.position), moveSpeed * Time.deltaTime);
    }
}
