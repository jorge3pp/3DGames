﻿using UnityEngine;
using System.Collections;

public class Debug : MonoBehaviour {

	public int X;
	public int Y;


}
