﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class JumpBlockResponse : MonoBehaviour
{
    private Rigidbody2D body;

    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if (tag == "Jump")
        {
            JumpTrigger jumpTrigger = collision.gameObject.GetComponent<JumpTrigger>();
            body.AddForce(jumpTrigger.jumpVector, ForceMode2D.Impulse);
        }
    }
}
