﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float direction = 1;
    public float speed = 3;
    public bool didBounce = false;

    private Rigidbody2D body;
    private SpriteRenderer sprite;
    private Animator animator;

    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        if (!didBounce)
        {
            body.velocity = new Vector2(direction * speed, body.velocity.y);
        }

        animator.SetFloat("yvelocity", body.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if (tag == "Bounce")
        {
            direction = direction * -1;
            sprite.flipX = !sprite.flipX;
        }
    }
}
