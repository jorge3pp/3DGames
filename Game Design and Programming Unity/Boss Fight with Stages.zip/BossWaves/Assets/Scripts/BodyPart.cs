﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyPart : MonoBehaviour
{
    public float Health = 100;
    public bool isDead = false;

    public void Hit(float damage)
    {
        Health -= damage;

        if (Health <= 0)
            isDead = true;
    }
}
