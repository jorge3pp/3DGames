﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public enum BossState
{
    Idle,
    LeftAttack,
    RightAttack,
    CenterAttack
}

public class BossController : MonoBehaviour
{
    public GameObject Player;
    public GameObject Beam;

    public Transform LeftArmSocket;
    public Transform RightArmSocket;

    public Transform LeftArmFirePoint;
    public Transform RightArmFirePoint;

    FollowPath followPath;

    public BossState State = BossState.Idle;

    public bool IsMoving = true;

    public GameObject bullet;
    public float fireTiming = 2;
    float elapsed = 0;

    public BodyPart[] BodyParts;

    void Start()
    {
        followPath = GetComponent<FollowPath>();

        UpdateMovementState(IsMoving);
        UpdateBossState(BossState.Idle);

       BodyParts = GetComponentsInChildren<BodyPart>();
    }

    void Update()
    {
        if (IsCharacterDead())
        {

        }
        else
        {
            elapsed += Time.deltaTime;

            switch (State)
            {
                case BossState.LeftAttack:

                    UpdateArmDirection(LeftArmSocket);

                    if (elapsed >= fireTiming)
                    {
                        FireBullet(LeftArmFirePoint);
                        elapsed = 0;
                    }
                    break;

                case BossState.RightAttack:

                    UpdateArmDirection(RightArmSocket);

                    if (elapsed >= fireTiming)
                    {
                        FireBullet(RightArmFirePoint);
                        elapsed = 0;
                    }
                    break;

                case BossState.CenterAttack:
                    Beam.SetActive(true);
                    break;
            }
        }
    }

    private bool IsCharacterDead()
    {
        int count = 0;
        for (int i = 0; i < BodyParts.Length; i++)
        {
            if (BodyParts[i].isDead)
                count++;
        }

        return count >= BodyParts.Length;
    }

    public void UpdateStateAfterTimer()
    {
        if ((int)State + 1 < Enum.GetValues(typeof(BossState)).Length)
        {
            State++;
        }
        else
        {
            State = 0;
        }

        UpdateBossState(State);
        Debug.Log("Boss State: " + State);
    }

    public void FireBullet(Transform spawnPoint)
    {
        Instantiate(bullet, spawnPoint.position, Quaternion.identity).GetComponent<BulletController>().Direction = -(spawnPoint.position - Player.transform.position);
    }

    public void UpdateBossState(BossState newState)
    {
        switch (State)
        {
            case BossState.Idle:
                Beam.SetActive(false);
                UpdateMovementState(true);
                Invoke("UpdateStateAfterTimer", 5);
                break;

            case BossState.LeftAttack:
                Beam.SetActive(false);
                UpdateMovementState(true);
                Invoke("UpdateStateAfterTimer", 5);
                break;

            case BossState.RightAttack:
                Beam.SetActive(false);
                UpdateMovementState(true);
                Invoke("UpdateStateAfterTimer", 5);
                break;

            case BossState.CenterAttack:
                Beam.SetActive(false);
                UpdateMovementState(false);
                Invoke("UpdateStateAfterTimer", 2);
                break;
        }
    }

    public void UpdateMovementState(bool doMove)
    {
        IsMoving = doMove;
        followPath.doMove = IsMoving;
    }

    void UpdateArmDirection(Transform armTransform)
    {
        Vector2 pos = armTransform.position - Player.transform.position;

        var rot = Quaternion.FromToRotation(armTransform.up, pos);
        armTransform.rotation = new Quaternion(0, 0, rot.z, 1);
    }
}
