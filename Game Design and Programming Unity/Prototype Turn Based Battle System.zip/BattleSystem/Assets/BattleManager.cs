﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleManager : MonoBehaviour
{
    public GameObject Player;
    public GameObject Enemy;
    Character playerScript;
    Character enemyScript;

    public Text playerHealth;
    public Text playerAP;

    public Text enemyHealth;
    public Text enemyAP;

    private void Start()
    {
        playerScript = Player.GetComponent<Character>();
        enemyScript = Enemy.GetComponent<Character>();
    }

    public void AddCharactersToBattle(GameObject player, GameObject enemy)
    {
        player.AddComponent(typeof(Character));
        enemy.AddComponent(typeof(Character));

        playerScript = player.GetComponent<Character>();
        playerScript.isCharactersTurn = true;

        enemyScript = enemy.GetComponent<Character>();
        enemyScript.isAI = true;

        playerScript.opponent = enemyScript;
        enemyScript.opponent = playerScript;
    }

    private void Update()
    {
        playerHealth.text = "Health: " + playerScript.Health;
        playerAP.text = "AP: " + playerScript.ActionPoints;

        enemyHealth.text = "Health: " + enemyScript.Health;
        enemyAP.text = "AP: " + enemyScript.ActionPoints;
    }
}
