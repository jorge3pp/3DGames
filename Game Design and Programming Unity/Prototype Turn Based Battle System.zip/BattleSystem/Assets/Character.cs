﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;
using Random = UnityEngine.Random;

//moves that can be made
[Serializable]
public enum BattleMove
{
    Heal,
    LightAttack,
    HeavyAttack,
    Stun,
    NoMove
}

public class Character : MonoBehaviour
{
    public bool isCharactersTurn = false;
    public bool isAI = false;
    public bool isStunned = false;

    public float Health = 100;

    public int ActionPoints = 10;
    public int maxActionPoints = 10;
    public int stunAmount = 2;
    private int currentStunCounter = 0;
    public float healAmount = 25;
    public float heavyAttackAmount = 30;
    public float lightAttackAmount = 10;
    public int maxHealsAllowed = 2;
    public int healsPerformed = 0;

    Dictionary<BattleMove, int> possibleMoves;

    public Character opponent;

    void Start()
    {
        //all possible moves the AP cost for each one
        possibleMoves = new Dictionary<BattleMove, int>();
        possibleMoves.Add(BattleMove.Heal, 2);
        possibleMoves.Add(BattleMove.HeavyAttack, 7);
        possibleMoves.Add(BattleMove.LightAttack, 3);
        possibleMoves.Add(BattleMove.Stun, 5);
    }

    void Update()
    {
        //if this is the AI and it's the AI turn
        if(isAI && isCharactersTurn)
        {
            //if teh AI is not stunned
            if(!isStunned)
            {
                //update the AI
                UpdateAI();
            }
            else
            {
                currentStunCounter--;

                if (currentStunCounter <= 0)
                    isStunned = false;
            }
        }
    }

    void UpdateAI()
    {
        //priorites healing
        if (Health <= 50 && CanAffordMove(BattleMove.Heal) && healsPerformed < maxHealsAllowed)
        {
            MakeMove(BattleMove.Heal);
            healsPerformed++;
        }
        else
        {
            BattleMove selectedMove = PickRandomMove();

            if (selectedMove != BattleMove.NoMove)
            {
                MakeMove(selectedMove);
            }
            else
            {
                EndTurn();
            }
        }
    }

    public void HandleMove(BattleMove move)
    {
        switch(move)
        {
            case BattleMove.HeavyAttack:
                Health -= heavyAttackAmount;
                break;

            case BattleMove.LightAttack:
                Health -= lightAttackAmount;
                break;

            case BattleMove.Stun:
                isStunned = true;
                currentStunCounter = stunAmount;
                break;
        }
    }

    public void MakeMove(BattleMove move)
    {
        if (CanAffordMove(move))
        {
            Debug.Log("IsAI: " + isAI + " , Move: " + move);

            if (move == BattleMove.Heal)
            {
                Health += healAmount;
            }
            else
            {
                opponent.HandleMove(move);
            }

            ActionPoints -= possibleMoves[move];
        }

        if (IsOutOfMoves())
        {
            EndTurn();
        }
    }

    private void EndTurn()
    {
        isCharactersTurn = false;
        opponent.ActionPoints = 10;
        opponent.isCharactersTurn = true;
    }

    public BattleMove PickRandomMove()
    {
        Dictionary<BattleMove, int> moves = possibleMoves.Where(
            m => 
            CanAffordMove(m.Key)).
            ToDictionary(m => m.Key, m => m.Value);

        if (moves.Count == 0)
            return BattleMove.NoMove;

        if (moves.ContainsKey(BattleMove.Heal))
            moves.Remove(BattleMove.Heal);

        if (moves.Count == 0)
            return BattleMove.NoMove;

        return moves.ElementAt(Random.Range(0, moves.Count - 1)).Key;
    }

    public void MakeMake(string move)
    {
        MakeMove((BattleMove)Enum.Parse(typeof(BattleMove), move));
    }

    public bool CanAffordMove(BattleMove desiredMove)
    {
        return possibleMoves[desiredMove] <= ActionPoints;
    }

    public bool IsOutOfMoves()
    {
        return ActionPoints < possibleMoves.Values.ToList().Min();
    }
}
