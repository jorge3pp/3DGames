﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridLayout : MonoBehaviour
{
    public int Width, Height;
    public GameObject tile;

    void Start()
    {
        for (int x = 0; x < Width; x++)
            for (int y = 0; y < Height; y++)
            {
                Vector3 position = new Vector2(x, y);
                position += transform.position;

                Instantiate(tile, position, Quaternion.identity, gameObject.transform);
            }
    }
}
