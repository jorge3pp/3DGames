﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RevealWithTrigger : MonoBehaviour
{

    private void OnTriggerEnter2D(Collider2D collision)
    {
        string tag = collision.gameObject.tag;

        if(tag == "Tile")
        {
            collision.gameObject.GetComponent<SpriteRenderer>().enabled = true;
        }
    }
}
