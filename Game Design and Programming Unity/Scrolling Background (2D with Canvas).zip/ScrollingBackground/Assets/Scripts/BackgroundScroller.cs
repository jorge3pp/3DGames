﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BackgroundScroller : MonoBehaviour
{
    public float scrollSpeed = 2;
    public Vector2 scrollDirection = new Vector2(-1, 0);

    //private MeshRenderer sprite;
    private Image sprite;
    void Start()
    {
        //sprite = GetComponent<MeshRenderer>();    
        sprite = GetComponent<Image>();
    }

    void Update()
    {
        sprite.material.mainTextureOffset += scrollDirection * scrollSpeed * Time.deltaTime;
    }
}
