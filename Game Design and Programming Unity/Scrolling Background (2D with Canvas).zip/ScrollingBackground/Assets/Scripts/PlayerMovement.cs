﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float horizontalSpeed = 5;
    public float jumpHeight = 10;
    public bool isOnGround = false;
    public bool canJump = true;

    private Vector2 inputAmount = Vector2.zero;
    public KeyCode jumpKey = KeyCode.Space;
    private Rigidbody2D body;

    public float direction = 0;
    public Vector3 lastCheckpoint;

    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        lastCheckpoint = transform.position;
    }

    void Update()
    {
        inputAmount.x = Input.GetAxis("Horizontal");
        inputAmount.y = Input.GetAxis("Vertical");

        direction = inputAmount.x;

        inputAmount *= horizontalSpeed;
        inputAmount.x = Vector2.ClampMagnitude(inputAmount, horizontalSpeed).x;
        inputAmount.y = body.velocity.y;

        body.velocity = inputAmount;

        if (canJump)
        {
            if (Input.GetKeyUp(jumpKey) && isOnGround)
            {
                body.AddForce(Vector2.up * jumpHeight, ForceMode2D.Impulse);
                isOnGround = false;
            }
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        string tag = collision.gameObject.tag;

        if(tag == "Ground")
        {
            if (IsBeneathCharacter(collision.gameObject.transform.position))
                isOnGround = true;
        }
    }

    private bool IsBeneathCharacter(Vector3 position)
    {
        return position.y < transform.position.y;
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        string tag = collider.gameObject.tag;

        if(tag == "Checkpoint")
        {
            lastCheckpoint = collider.gameObject.transform.position;
        }
        else if(tag == "Kill")
        {
            transform.position = lastCheckpoint;
        }
    }
}

