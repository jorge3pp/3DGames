﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Direction
{
    Idle = 0,
    Up = 1,
    Down = 2,
    Left = 3,
    Right = 4
}

public class PlayerAnimationControllerWithEnum : MonoBehaviour
{
    private Animator animator;
    private Direction State = Direction.Idle;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");

        State = Direction.Idle;

        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            State = Direction.Left;
        }
        else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            State  = Direction.Right;
        }

        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            State = Direction.Up;
        }
        else if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {
            State = Direction.Down;
        }

        //convert the Direction enum to an int
        animator.SetInteger("direction", (int)State);
    }
}
