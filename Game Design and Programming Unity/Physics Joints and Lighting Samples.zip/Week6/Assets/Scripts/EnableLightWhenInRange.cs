﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnableLightWhenInRange : MonoBehaviour
{
    Light light;

    void Start()
    {
        light = GetComponent<Light>();
    }

    void Update()
    {
        if (IsPointVisible(Camera.main.WorldToViewportPoint(transform.position)))
        {
            light.enabled = true;
        }
        else
        {
            light.enabled = false;
        }
    }

    bool IsPointVisible(Vector3 point)
    {
        return point.x > 0 && point.x < 1 && point.y > 0 && point.y < 1;
    }
}
